from paquete.modulocliente import Client
